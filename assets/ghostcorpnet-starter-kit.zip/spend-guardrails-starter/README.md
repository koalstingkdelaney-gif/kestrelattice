# Agent Spend Guardrails — Starter Pack

A minimal **ghostcorpnet Pack Standard v1** pack. Copy this structure to build your own pack.

## What's inside

| File | Purpose |
|---|---|
| `pack.json` | Manifest. Describes the pack per Pack Standard v1 §2. |
| `README.md` | This file — required by the spec. |
| `LICENSE` | MIT license covering this pack's contents — required by the spec. |
| `policies/spend-limit-policy.md` | Sample policy template: per-agent and per-run spend limits, with fill-in blanks. |
| `runbooks/cost-alert-runbook.md` | Sample runbook: what to do when a cost alert fires. |
| `schemas/budget.schema.json` | Sample JSON schema: budget envelope shape for agent runs. |

## How to use

1. Fill in the `[BRACKETED]` blanks in `policies/spend-limit-policy.md` for your org.
2. Adapt the runbook steps to your alerting tool (PagerDuty, Slack, email — whatever you use).
3. Validate `schemas/budget.schema.json` against your budget config with any JSON Schema validator.
4. When you publish your own pack, update `pack.json` (`name`, `title`, `builder`, `version`, `checksum` per §4 of the spec).

## Validity

This pack validates against Pack Standard v1: manifest present, ≥1 governance artifact,
README and LICENSE at root, all section paths exist, checksum matches the distributed ZIP.
