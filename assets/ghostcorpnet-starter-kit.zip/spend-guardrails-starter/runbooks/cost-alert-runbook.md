# Cost Alert Response Runbook

*Adapt channel names and tooling to your stack. Target: acknowledge in 15 minutes.*

## Trigger

A cost alert fires from your billing monitor when an agent or org crosses a spend threshold
defined in the spend limit policy.

## Steps

1. **Acknowledge** — Claim the alert in [ALERTING TOOL]. Note the agent id, run id, and current spend vs. cap.
2. **Assess** — Open the run's audit log. Classify:
   - *Expected* (large batch job, approved) → confirm approval exists, extend monitoring, close alert.
   - *Looping agent* (repeated tool calls, no progress) → go to step 3.
   - *Unknown* → treat as looping until proven otherwise.
3. **Contain** — Pause the run. Do not delete logs. If the agent is external/vendor-hosted, revoke its API key and rotate.
4. **Decide** — With [ROLE, e.g. Eng Lead]:
   - Resume with a tighter cap, or
   - Kill the run and roll back side effects, or
   - Approve continued spend (record the approval).
5. **Record** — Log the incident: trigger, classification, action taken, final cost. Link it in the audit trail.
6. **Review** — Within 2 business days, add a prevention note: was the cap wrong, the alert late, or the agent misbehaving? Update the policy.

## Escalation

No acknowledgment in 15 minutes → page [ON-CALL].
Spend above $[HARD STOP AMOUNT] → automatic kill switch engages; notify [ROLE] immediately.
